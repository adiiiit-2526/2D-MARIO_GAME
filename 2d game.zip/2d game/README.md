# Mario 2D Game

This Java project contains a 2D game engine, a level editor, and a Mario-style sample level. It is based on the [Coding a 2D Game Engine in Java series](https://www.youtube.com/watch?v=VyKE7vz65rY&list=PLtrSb4XxIVbp8AKuEAlwNXDxr99e3woGE).

## Run the game

Install a JDK and Gradle, then open a terminal in the project root (the folder containing `build.gradle`) and run:

```text
gradle run
```

On Windows, `run.bat` runs the same command. Keep the terminal's working directory at the project root so the game can find `assets/` and `level.txt`. The first run may download the dependencies declared in `build.gradle`.

To compile without launching:

```text
gradle classes
```

The project uses Gradle as its build system. The obsolete Maven build file and incomplete Gradle wrapper scripts were removed; a system Gradle installation is required.

## Project files

### Root files

| File | Purpose |
|---|---|
| `build.gradle` | Gradle plugins, dependencies, application entry point, and packaging tasks. |
| `settings.gradle` | Names the Gradle project `mario`. |
| `run.bat` | Windows shortcut for `gradle run`. |
| `level.txt` | Serialized sample level loaded by the game/editor. |
| `LICENSE` | License and attribution information. |
| `.gitignore` | Files and folders that should not be tracked as source. |
| `README.md` | Run instructions and project file guide. |
| `Java_Topics_Implementation_Guide.docx` | Java concept checklist, source locations, and implementation status. |

### Runtime resources

| Path | Purpose |
|---|---|
| `assets/images/` | Sprites, tiles, editor icons, and other textures used by the game/editor. |
| `assets/sounds/` | OGG sound effects and music. |
| `assets/shaders/` | GLSL shaders for sprites, picking, and debug lines. |
| `libs/jbox2d-library.jar` | Local JBox2D physics dependency referenced by `build.gradle`. |

The retained runtime resources are:

| File | Purpose |
|---|---|
| `assets/images/bigSpritesheet.png` | Image atlas referenced by the sample level. |
| `assets/images/items.png` | Item atlas referenced by the sample level. |
| `assets/images/pipes.png` | Pipe graphics referenced by the sample level. |
| `assets/images/spritesheet.png` | Player sprite atlas used by the game and editor. |
| `assets/images/turtle.png` | Image referenced by the sample level. |
| `assets/images/spritesheets/decorationsAndBlocks.png` | Blocks and decorations referenced by the sample level. |
| `assets/sounds/jump-small.ogg` | Player jump sound. |
| `assets/sounds/main-theme-overworld.ogg` | Gameplay background music. |
| `assets/sounds/mario_die.ogg` | Player death sound. |
| `assets/shaders/debugLine2D.glsl` | Shader for debug lines. |
| `assets/shaders/default.glsl` | Main sprite-rendering shader. |
| `assets/shaders/pickingShader.glsl` | Shader used for editor object picking. |

Image references are also stored in `level.txt`; keep these files together with the level data.

## Java source file guide

All application code is under `src/main/java/`. The package directories separate engine subsystems.

### Application entry point

| File | Purpose |
|---|---|
| `Main.java` | Starts the application by obtaining the window and entering its game loop. |

### `components/`

| File | Purpose |
|---|---|
| `AnimationState.java` | Stores and updates an animation's frames, timing, and loop behavior. |
| `Component.java` | Base class for components attached to game objects; defines lifecycle, collision, and editor hooks. |
| `ComponentDeserializer.java` | Serializes and deserializes component instances with Gson. |
| `EditorCamera.java` | Handles editor-camera navigation and zoom controls. |
| `Frame.java` | Stores a sprite and the duration of one animation frame. |
| `GameCamera.java` | Component that connects a camera to a game object. |
| `GridLines.java` | Draws the editor grid. |
| `Ground.java` | Marks ground objects used by player/gameplay logic. |
| `KeyControls.java` | Handles keyboard controls for game objects. |
| `MouseControls.java` | Handles mouse-based object selection and interaction. |
| `NonPickable.java` | Marks objects that should not be selected by editor picking. |
| `PlayerController.java` | Implements player movement and gameplay input. |
| `Sprite.java` | Represents a sprite's texture region and render properties. |
| `SpriteRenderer.java` | Component that renders a sprite for its game object. |
| `Spritesheet.java` | Splits a texture into individual sprites. |
| `StateMachine.java` | Selects animation states and transitions between them using triggers. |

### `editor/`

| File | Purpose |
|---|---|
| `GameViewWindow.java` | Displays the game framebuffer in the editor viewport. |
| `JImGui.java` | Provides reusable Dear ImGui controls for vectors, numbers, colors, and text. |
| `MenuBar.java` | Builds the editor menu bar and its actions. |
| `PropertiesWindow.java` | Displays and edits selected game-object properties and components. |
| `SceneHierarchyWindow.java` | Displays the scene's object hierarchy and selection controls. |

### `jade/`

| File | Purpose |
|---|---|
| `Camera.java` | Holds camera projection/view matrices, position, and zoom. |
| `GameObject.java` | Entity that owns components, identity, and lifecycle state. |
| `GameObjectDeserializer.java` | Reconstructs game objects and their components from Gson data. |
| `ImGuiLayer.java` | Initializes and renders the Dear ImGui interface. |
| `KeyListener.java` | Tracks keyboard input received from GLFW. |
| `MouseListener.java` | Tracks mouse position, buttons, and scroll input. |
| `Prefabs.java` | Creates reusable, preconfigured game objects. |
| `Sound.java` | Loads and plays audio resources. |
| `Transform.java` | Component for an object's position, rotation, and scale. |
| `Window.java` | Creates the GLFW window, initializes subsystems, and runs the main loop. |

### `observers/` and `observers/events/`

| File | Purpose |
|---|---|
| `observers/Observer.java` | Interface for objects that receive events. |
| `observers/EventSystem.java` | Registers observers and dispatches events. |
| `observers/events/Event.java` | Event data passed to observers. |
| `observers/events/EventType.java` | Enumerates event types. |

### `physics2d/`

| File | Purpose |
|---|---|
| `JadeContactListener.java` | Bridges JBox2D contact callbacks to game objects/components. |
| `Physics2D.java` | Creates and steps the physics world and provides physics queries. |
| `RaycastInfo.java` | Stores raycast results and implements the JBox2D raycast callback. |
| `components/Box2DCollider.java` | Box-shaped physics collider component. |
| `components/CircleCollider.java` | Circle-shaped physics collider component. |
| `components/PillboxCollider.java` | Pill-shaped physics collider component. |
| `components/Rigidbody2D.java` | Attaches and configures a physics body for a game object. |
| `enums/BodyType.java` | Defines supported body types. |

### `renderer/`

| File | Purpose |
|---|---|
| `DebugDraw.java` | Draws temporary debug lines. |
| `Framebuffer.java` | Manages an OpenGL framebuffer and its texture attachment. |
| `Line2D.java` | Represents a 2D line used for debug drawing. |
| `PickingTexture.java` | Renders object IDs for selecting objects in the editor. |
| `RenderBatch.java` | Batches compatible sprites into render calls. |
| `Renderer.java` | Collects sprites and coordinates render batches. |
| `Shader.java` | Loads, compiles, and uses OpenGL shaders. |
| `Texture.java` | Loads and manages an OpenGL texture. |

### `scenes/`

| File | Purpose |
|---|---|
| `LevelEditorSceneInitializer.java` | Creates and configures the level-editor scene and its resources. |
| `LevelSceneInitializer.java` | Creates and configures the sample gameplay scene. |
| `Scene.java` | Owns scene objects, updates/renders them, and saves or loads scene data. |
| `SceneInitializer.java` | Base class for scene-specific setup. |

### `util/`

| File | Purpose |
|---|---|
| `AssetPool.java` | Caches and retrieves textures, shaders, spritesheets, and sounds. |
| `JMath.java` | Shared vector and numeric math helpers. |
| `Settings.java` | Shared editor/game settings such as grid dimensions. |

## Java topic checklist

The Word guide maps each requested Java topic to exact source line numbers and indicates whether it is present in the game code. The separate teaching-only example class has been removed because it was not needed to run the game. Topics absent from the game code are marked as not implemented in the guide rather than being presented as game features.

## Cleanup notes

The project retains its Gradle build, runtime code/resources, sample level, standard license/source-control files, and documentation. Unreferenced image and sound files, generated Gradle/Maven build outputs, the generated editor-layout file, an outdated Maven build file, incomplete Gradle wrapper scripts, a duplicate source manifest, and non-game tooling files were removed. Gradle and the game can regenerate generated files when needed.
